/**
 * 
 */
function change(){
	var s = document.getElementById("img_change");
	s.src = "/first/YANZHENGservlet?a="+new Date().getTime();
}