package ii.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



public class Login_servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Login_servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("......");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		//������֤��
		String Sec_code = (String)request.getSession().getAttribute("S_code");
		String now_code = request.getParameter("key_ma");
		if(!Sec_code.equalsIgnoreCase(now_code))
		{
			request.setAttribute("msg", "��֤�����");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return;
		}
		
		//������¼��Ϣ
		String username = request.getParameter("username");
		String password = request.getParameter("pass");
		//У��
		if("wxn".equals(username)&&"123456".equals(password)) {//��½�ɹ�
			HttpSession session  =request.getSession();//��ȡsession
			session.setAttribute("username", username);
			session.setAttribute("pass", password);//��session���б�������
			response.sendRedirect("/first/f_1.jsp");
		}else {//��¼ʧ��
			request.setAttribute("msg", "�û������������");
			RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");//ת����
			rd.forward(request, response);//ת��
		}
	}

}
