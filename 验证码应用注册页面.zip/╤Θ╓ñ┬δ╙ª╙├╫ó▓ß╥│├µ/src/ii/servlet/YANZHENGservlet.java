package ii.servlet;

import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ii.java.Code;

public class YANZHENGservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			Code c = new Code();
			BufferedImage sc = c.getImage();
			request.getSession().setAttribute("S_code", c.getText());//����ͼƬ�ϵ��ı�
			Code.output(sc, response.getOutputStream());
	}

}
